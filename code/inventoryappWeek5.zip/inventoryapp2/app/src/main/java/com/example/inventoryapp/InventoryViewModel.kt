package com.example.inventoryapp

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.inventoryapp.database.DatabaseHelper
import com.example.inventoryapp.model.InventoryItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * InventoryViewModel owns all business logic and data operations for the
 * inventory screen. It exposes a single [StateFlow] of [InventoryUiState]
 * that the UI observes; the activity and composables contain no logic.
 *
 * Enhancement (Software Design & Engineering):
 * Previously, all database calls, coroutine launches, permission checks, and
 * UI state variables lived inside InventoryActivity as a single monolithic class.
 * Moving them here achieves separation of concerns and single responsibility:
 *   - The ViewModel survives configuration changes (screen rotation) automatically.
 *   - Composables receive state and callbacks only — they own no business logic.
 *   - Database operations run on Dispatchers.IO, never blocking the main thread.
 *   - Unit tests can target the ViewModel directly without an Activity context.
 *
 * AndroidViewModel is used (rather than plain ViewModel) because DatabaseHelper
 * still requires an Android Context. This dependency will be removed when the
 * Databases enhancement migrates DatabaseHelper to Room with a Repository pattern.
 */
class InventoryViewModel(application: Application) : AndroidViewModel(application) {

    private val databaseHelper = DatabaseHelper(application)

    private val _uiState = MutableStateFlow(InventoryUiState())
    val uiState: StateFlow<InventoryUiState> = _uiState.asStateFlow()

    // The current username is set once when the activity launches.
    private var username: String = ""

    // -------------------------------------------------------------------------
    // Initialisation
    // -------------------------------------------------------------------------

    /**
     * Called from InventoryActivity.onCreate after extracting the username from
     * the launch intent. Triggers the initial inventory load.
     */
    fun initialize(username: String) {
        this.username = username
        loadItems()
    }

    // -------------------------------------------------------------------------
    // Data operations
    // -------------------------------------------------------------------------

    /**
     * Loads all inventory items for the current user from the database.
     * Runs on the IO dispatcher so the main thread is never blocked.
     */
    fun loadItems() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                val items = withContext(Dispatchers.IO) {
                    databaseHelper.getInventoryItems(username)
                }
                _uiState.update { it.copy(items = items, isLoading = false) }
            } catch (e: Exception) {
                Log.e(TAG, "Error loading items: ${e.message}")
                _uiState.update {
                    it.copy(isLoading = false, userMessage = "Error loading items: ${e.message}")
                }
            }
        }
    }

    /**
     * Adds a new inventory item and refreshes the list on success.
     */
    fun addItem(item: InventoryItem) {
        viewModelScope.launch {
            try {
                val success = withContext(Dispatchers.IO) {
                    databaseHelper.addInventoryItem(item, username)
                }
                if (success) {
                    _uiState.update { it.copy(showAddDialog = false, userMessage = "Item added") }
                    loadItems()
                } else {
                    _uiState.update { it.copy(userMessage = "Failed to add item") }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error adding item: ${e.message}")
                _uiState.update { it.copy(userMessage = "Error adding item: ${e.message}") }
            }
        }
    }

    /**
     * Persists changes to an existing inventory item and refreshes the list.
     */
    fun updateItem(item: InventoryItem) {
        viewModelScope.launch {
            try {
                val success = withContext(Dispatchers.IO) {
                    databaseHelper.updateInventoryItem(item)
                }
                if (success) {
                    _uiState.update { it.copy(editingItem = null, userMessage = "Item updated") }
                    loadItems()
                } else {
                    _uiState.update { it.copy(userMessage = "Failed to update item") }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error updating item: ${e.message}")
                _uiState.update { it.copy(userMessage = "Error updating item: ${e.message}") }
            }
        }
    }

    /**
     * Deletes an inventory item by ID and refreshes the list.
     */
    fun deleteItem(itemId: Long) {
        viewModelScope.launch {
            try {
                val success = withContext(Dispatchers.IO) {
                    databaseHelper.deleteInventoryItem(itemId)
                }
                if (success) {
                    _uiState.update { it.copy(userMessage = "Item deleted") }
                    loadItems()
                } else {
                    _uiState.update { it.copy(userMessage = "Failed to delete item") }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error deleting item: ${e.message}")
                _uiState.update { it.copy(userMessage = "Error deleting item: ${e.message}") }
            }
        }
    }

    // -------------------------------------------------------------------------
    // UI event handlers — called directly from composables via callbacks
    // -------------------------------------------------------------------------

    /** Opens the add-item dialog. */
    fun onAddItemClicked() {
        _uiState.update { it.copy(showAddDialog = true) }
    }

    /** Opens the edit dialog pre-populated with [item]. */
    fun onEditItemClicked(item: InventoryItem) {
        _uiState.update { it.copy(editingItem = item) }
    }

    /** Dismisses whichever dialog is currently open. */
    fun onDialogDismissed() {
        _uiState.update { it.copy(showAddDialog = false, editingItem = null) }
    }

    /**
     * Clears the one-shot user message after the UI has displayed it
     * (e.g. after a Toast or Snackbar has been shown).
     */
    fun onUserMessageShown() {
        _uiState.update { it.copy(userMessage = null) }
    }

    /**
     * Called by the activity once SMS permission status is known.
     * Triggers a low-stock check if permission is granted.
     */
    fun onSmsPermissionResult(granted: Boolean) {
        if (granted) checkLowStock()
    }

    // -------------------------------------------------------------------------
    // SMS / low-stock logic (kept in ViewModel, not the Activity)
    // -------------------------------------------------------------------------

    /**
     * Checks for low-stock items and exposes a user message for the activity
     * to surface as an SMS alert if permission has been granted.
     */
    private fun checkLowStock() {
        viewModelScope.launch {
            try {
                val lowStock = withContext(Dispatchers.IO) {
                    databaseHelper.getLowStockItems(username)
                }
                if (lowStock.isNotEmpty()) {
                    val names = lowStock.take(3).joinToString { "${it.name} (${it.quantity})" }
                    val extra = if (lowStock.size > 3) " +${lowStock.size - 3} more" else ""
                    _uiState.update {
                        it.copy(userMessage = "Low stock: $names$extra")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Low stock check failed: ${e.message}")
            }
        }
    }

    companion object {
        private const val TAG = "InventoryViewModel"
    }
}
