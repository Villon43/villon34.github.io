package com.example.inventoryapp

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.inventoryapp.model.InventoryItem

/**
 * Top-level inventory screen composable.
 *
 * Enhancement (Software Design & Engineering):
 * Previously, InventoryScreen, InventoryItemCard, and AddEditItemDialog were all
 * defined as inner functions of InventoryActivity, giving them direct access to
 * activity-level fields. They are now top-level composables in their own file.
 *
 * Each composable is "stateless" from the perspective of business logic:
 *   - It receives [InventoryUiState] as a snapshot of truth from the ViewModel.
 *   - User interactions are forwarded via typed callbacks (onAddItem, onEditItem, etc.).
 *   - No database calls, coroutines, or Android context references exist here.
 *
 * This makes every composable independently previewable and unit-testable.
 *
 * @param uiState       The current UI state emitted by [InventoryViewModel].
 * @param onAddClicked  Called when the user taps the FAB to open the add dialog.
 * @param onSaveNew     Called with the new [InventoryItem] when the add form is submitted.
 * @param onSaveEdit    Called with the updated [InventoryItem] when the edit form is submitted.
 * @param onDelete      Called with the item ID when the user taps delete.
 * @param onEditClicked Called with the tapped [InventoryItem] to open the edit dialog.
 * @param onDismiss     Called when either dialog is dismissed without saving.
 */
@Composable
fun InventoryScreen(
    uiState: InventoryUiState,
    onAddClicked: () -> Unit,
    onSaveNew: (InventoryItem) -> Unit,
    onSaveEdit: (InventoryItem) -> Unit,
    onDelete: (Long) -> Unit,
    onEditClicked: (InventoryItem) -> Unit,
    onDismiss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // ── Header row ──────────────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Inventory",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Items: ${uiState.items.size}",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            FloatingActionButton(
                onClick = onAddClicked,
                modifier = Modifier.size(56.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Item")
            }
        }

        // ── Loading indicator ────────────────────────────────────────────────
        if (uiState.isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Column
        }

        // ── Empty state ──────────────────────────────────────────────────────
        if (uiState.items.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "No inventory items yet.\nTap the + button to add your first item!",
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            // ── Item list ────────────────────────────────────────────────────
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(uiState.items) { item ->
                    InventoryItemCard(
                        item = item,
                        onEdit = onEditClicked,
                        onDelete = onDelete
                    )
                }
            }
        }
    }

    // ── Dialogs (rendered outside the Column so they overlay everything) ────
    if (uiState.showAddDialog) {
        AddEditItemDialog(
            item = null,
            onDismiss = onDismiss,
            onSave = onSaveNew
        )
    }

    uiState.editingItem?.let { item ->
        AddEditItemDialog(
            item = item,
            onDismiss = onDismiss,
            onSave = onSaveEdit
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// InventoryItemCard
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Displays a single inventory item as a Material3 card.
 * Stateless — receives the item and event callbacks only.
 */
@Composable
fun InventoryItemCard(
    item: InventoryItem,
    onEdit: (InventoryItem) -> Unit,
    onDelete: (Long) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEdit(item) },
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.name,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (item.description.isNotBlank()) {
                        Text(
                            text = item.description,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    if (item.category.isNotBlank()) {
                        Text(
                            text = "Category: ${item.category}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }

                Row {
                    IconButton(onClick = { onEdit(item) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { onDelete(item.id) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete")
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Qty: ${item.quantity}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                    if (item.isLowStock()) {
                        Box(
                            modifier = Modifier
                                .padding(start = 8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.error)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "LOW STOCK",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onError,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Text(
                    text = String.format("$%.2f", item.price),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// AddEditItemDialog
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Dialog for creating or editing an inventory item.
 *
 * When [item] is null the dialog is in "add" mode; when non-null it pre-populates
 * the form fields for editing. Local form state (name, quantity, etc.) is scoped
 * to this composable via [remember] — it is intentionally ephemeral and never
 * promoted to the ViewModel, since it only matters while the dialog is open.
 *
 * @param item      Existing item to edit, or null for a new item.
 * @param onDismiss Called when the user cancels or taps outside the dialog.
 * @param onSave    Called with the constructed [InventoryItem] on confirmation.
 */
@Composable
fun AddEditItemDialog(
    item: InventoryItem?,
    onDismiss: () -> Unit,
    onSave: (InventoryItem) -> Unit
) {
    var name        by remember { mutableStateOf(item?.name        ?: "") }
    var description by remember { mutableStateOf(item?.description ?: "") }
    var quantity    by remember { mutableStateOf(item?.quantity?.toString() ?: "") }
    var price       by remember { mutableStateOf(item?.price?.toString()    ?: "") }
    var category    by remember { mutableStateOf(item?.category    ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (item == null) "Add New Item" else "Edit Item",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Item Name *") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { if (it.all { c -> c.isDigit() }) quantity = it },
                        label = { Text("Quantity *") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = price,
                        onValueChange = {
                            if (it.matches(Regex("^\\d*\\.?\\d{0,2}$"))) price = it
                        },
                        label = { Text("Price *") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            val qty   = quantity.toIntOrNull()    ?: 0
                            val cost  = price.toDoubleOrNull()    ?: 0.0
                            if (name.isNotBlank() && qty >= 0 && cost >= 0.0) {
                                onSave(
                                    InventoryItem(
                                        id          = item?.id ?: 0L,
                                        name        = name.trim(),
                                        description = description.trim(),
                                        quantity    = qty,
                                        price       = cost,
                                        category    = category.trim()
                                    )
                                )
                            }
                        },
                        enabled = name.isNotBlank() &&
                                quantity.isNotBlank() &&
                                price.isNotBlank()
                    ) {
                        Text(if (item == null) "Add" else "Save")
                    }
                }
            }
        }
    }
}
