package com.example.inventoryapp.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

/**
 * Data Access Object for user authentication operations.
 *
 * Enhancement Milestone Four:
 * All SQL that was previously written as raw strings inside DatabaseHelper
 * is now expressed as annotated suspend functions in this DAO. Room validates
 * every @Query at compile time.
 *
 * Functions are [suspend] so they run on the coroutine dispatcher configured
 * in [AppDatabase] (Dispatchers.IO) without blocking the main thread.
 */
@Dao
interface UserDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertUser(user: UserEntity): Long

    @Query("SELECT password FROM users WHERE username = :username LIMIT 1")
    suspend fun getPasswordHash(username: String): String?

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): UserEntity?
}
