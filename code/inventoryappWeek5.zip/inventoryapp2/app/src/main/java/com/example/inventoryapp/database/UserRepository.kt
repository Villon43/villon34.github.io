package com.example.inventoryapp.database

import android.util.Log
import at.favre.lib.crypto.bcrypt.BCrypt

/**
 * UserRepository abstracts user authentication operations behind a clean API,
 * keeping BCrypt and DAO details out of the ViewModel.
 *
 * Enhancement Milestone Four:
 * The original [DatabaseHelper.createUser] and [DatabaseHelper.authenticateUser]
 * stored and compared passwords as plaintext strings — a critical security
 * vulnerability identified in the code review. Any attacker who obtained
 * access to the SQLite database file (trivially possible on a rooted device or
 * via an ADB backup) would have immediate access to every user's credentials.
 *
 * This repository replaces plaintext storage with BCrypt, an adaptive
 * password-hashing function designed specifically for credential storage:
 *
 *   CREATION:  BCrypt.withDefaults().hashToString(cost, password.toCharArray())
 *              produces a 60-character hash string that embeds the algorithm
 *              identifier, cost factor, and salt. The salt is randomly generated
 *              per hash, so two users with the same password produce different
 *              hashes.
 *
 *   VERIFICATION: BCrypt.verifyer().verify(password.toCharArray(), storedHash)
 *                 extracts the embedded salt, re-hashes the candidate password,
 *                 and compares in constant time, preventing timing attacks.
 *
 * The cost factor (BCRYPT_COST = 12) controls the work factor. At cost 12,
 * BCrypt requires ~250 ms on a modern CPU per hash — fast enough for a user
 * login but slow enough to make offline brute-force attacks impractical.
 * This is why [createUser] and [authenticateUser] are suspend functions
 * dispatched to the IO thread by the caller.
 *
 * @param userDao The [UserDao] used for all database operations.
 */
class UserRepository(private val userDao: UserDao) {

    companion object {
        private const val TAG          = "UserRepository"
        /**
         * BCrypt cost factor. Each increment doubles the computation time.
         * 12 is the current industry-standard minimum for new systems.
         * Increase to 13 or 14 as hardware improves.
         */
        private const val BCRYPT_COST  = 12
    }


    suspend fun createUser(username: String, password: String): Boolean {
        return try {
            val hash = BCrypt
                .withDefaults()
                .hashToString(BCRYPT_COST, password.toCharArray())
            val newUser = UserEntity(username = username, passwordHash = hash)
            userDao.insertUser(newUser) != -1L
        } catch (e: Exception) {
            Log.e(TAG, "Error creating user: ${e.message}")
            false
        }
    }

    suspend fun authenticateUser(username: String, password: String): Boolean {
        return try {
            val storedHash = userDao.getPasswordHash(username) ?: return false
            val result = BCrypt
                .verifyer()
                .verify(password.toCharArray(), storedHash)
            result.verified
        } catch (e: Exception) {
            Log.e(TAG, "Error authenticating user: ${e.message}")
            false
        }
    }

    /**
     * Returns the [UserEntity] for [username], or null if not found.
     * Used by [InventoryRepository] when it needs the user_id for an insert.
     */
    suspend fun getUser(username: String): UserEntity? {
        return try {
            userDao.getUserByUsername(username)
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching user: ${e.message}")
            null
        }
    }
}
