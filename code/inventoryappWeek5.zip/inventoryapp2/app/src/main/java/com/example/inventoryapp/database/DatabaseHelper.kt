package com.example.inventoryapp.database

import android.content.Context
import com.example.inventoryapp.model.InventoryItem

/**
 * DatabaseHelper — compatibility facade over the Room database layer.
 *
 *  Milestone Four:
 * The original DatabaseHelper extended SQLiteOpenHelper and contained all
 * database logic directly. It has been fully replaced by the Room layer
 * (AppDatabase, UserDao, InventoryItemDao, UserRepository, InventoryRepository).
 *
 * This class now acts as a thin facade that preserves the public API that
 * InventoryViewModel and MainActivity already call, delegating every operation
 * to the appropriate repository. This means zero changes are required in the
 * ViewModel or Activity, only the database layer has changed, which is the
 * correct boundary for this kind of infrastructure migration.
 *
 * In a production codebase the next step would be to inject the repositories
 * directly into the ViewModel (via a ViewModelFactory or a DI framework like
 * Hilt), and retire this facade entirely. For the capstone, the facade keeps
 * the scope of change focused on the database layer as planned.
 */
class DatabaseHelper(context: Context) {

    companion object {
        /** Low-stock threshold shared with [com.example.inventoryapp.model.InventoryItem]. */
        const val LOW_STOCK_THRESHOLD = 5
    }

    private val db                  = AppDatabase.getInstance(context)
    private val userRepository      = UserRepository(db.userDao())
    private val inventoryRepository = InventoryRepository(db.inventoryItemDao(), userRepository)

    // Authentication 

    /**
     * Creates a user account with a BCrypt-hashed password.
     * Delegates to [UserRepository.createUser].
     */
    suspend fun createUser(username: String, password: String): Boolean =
        userRepository.createUser(username, password)

    /**
     * Verifies login credentials using BCrypt hash comparison.
     * Delegates to [UserRepository.authenticateUser].
     */
    suspend fun authenticateUser(username: String, password: String): Boolean =
        userRepository.authenticateUser(username, password)

    // Inventory CRUD 

    suspend fun addInventoryItem(item: InventoryItem, username: String): Boolean =
        inventoryRepository.addInventoryItem(item, username)

    suspend fun getInventoryItems(username: String): List<InventoryItem> =
        inventoryRepository.getInventoryItems(username)

    suspend fun updateInventoryItem(item: InventoryItem): Boolean =
        inventoryRepository.updateInventoryItem(item)

    suspend fun deleteInventoryItem(itemId: Long): Boolean =
        inventoryRepository.deleteInventoryItem(itemId)

    suspend fun getLowStockItems(
        username: String,
        threshold: Int = LOW_STOCK_THRESHOLD
    ): List<InventoryItem> =
        inventoryRepository.getLowStockItems(username, threshold)
}
