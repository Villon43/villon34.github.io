package com.example.inventoryapp.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Room entity representing a row in the [inventory_items] table.
 *
 * Enhancement Milestone Four:
 * The original CREATE TABLE statement was a raw SQL string constant.
 * Room replaces it with a validated, annotated data class. Three key
 * structural elements from the Milestone Three schema are preserved:
 *
 * 1. FOREIGN KEY on [userId] referencing [UserEntity.userId], enforcing
 *    referential integrity at the database level.
 * 2. INDEXES on [userId], [itemName], and [category] — carried forward
 *    from the Milestone Three index additions. Room's @Entity indices
 *    parameter generates the same CREATE INDEX statements that were
 *    previously written by hand.
 * 3. DEFAULT values on [quantity] (0) and [price] (0.0) preserved via
 *    [defaultValue] in @ColumnInfo.
 */
@Entity(
    tableName = "inventory_items",
    foreignKeys = [
        ForeignKey(
            entity        = UserEntity::class,
            parentColumns = ["user_id"],
            childColumns  = ["user_id"],
            onDelete      = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["user_id"]),     
        Index(value = ["item_name"]),    
        Index(value = ["category"])       
    ]
)
data class InventoryItemEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "item_id")
    val itemId: Long = 0L,

    @ColumnInfo(name = "item_name")
    val itemName: String,

    @ColumnInfo(name = "item_description")
    val itemDescription: String = "",

    @ColumnInfo(name = "quantity", defaultValue = "0")
    val quantity: Int = 0,

    @ColumnInfo(name = "price", defaultValue = "0.0")
    val price: Double = 0.0,

    @ColumnInfo(name = "category")
    val category: String = "",

    @ColumnInfo(name = "user_id", index = true)
    val userId: Long
)
