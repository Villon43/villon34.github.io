package com.example.inventoryapp.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * AppDatabase is the Room database for the inventory application.
 *
 * Enhancement Milestone Four:
 * Replaces SQLiteOpenHelper as the database management layer. Room provides:
 *   - Compile-time SQL validation for every @Query in the DAOs.
 *   - Automatic cursor-to-object mapping, eliminating the manual
 *     cursorToInventoryItem() helper that was needed in Milestone Three.
 *   - Built-in coroutine support via suspend DAO functions.
 *   - A structured migration API (used here with fallbackToDestructiveMigration
 *     for simplicity in a capstone context; a production app would supply
 *     explicit Migration objects to preserve user data across schema changes).
 *
 * Version is set to 3 to succeed the SQLiteOpenHelper versions 1 (original)
 * and 2 (Milestone Three indexes). On devices that had the older
 * SQLiteOpenHelper database, fallbackToDestructiveMigration() will drop and
 * recreate the schema cleanly. For the purposes of this capstone the trade-off
 * of losing existing test data in favour of a clean Room schema is acceptable;
 * a production migration would supply Room Migration objects instead.
 *
 */
@Database(
    entities  = [UserEntity::class, InventoryItemEntity::class],
    version   = 3,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun inventoryItemDao(): InventoryItemDao

    companion object {
        private const val DB_NAME = "inventory_database.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DB_NAME
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
