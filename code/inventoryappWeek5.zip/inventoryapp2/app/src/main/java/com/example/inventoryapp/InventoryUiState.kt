package com.example.inventoryapp

import com.example.inventoryapp.model.InventoryItem

/**
 * Represents the complete UI state for the inventory screen.
 *
 * Using a single sealed state class rather than scattered mutableStateOf fields
 * ensures that the UI always renders a consistent snapshot. The ViewModel emits
 * a new state object on every meaningful change; composables simply react to it.
 *
 * Enhancement: replaces ad-hoc mutableStateOf variables that were previously
 * scattered across InventoryActivity's composable inner functions.
 */
data class InventoryUiState(
    val items: List<InventoryItem> = emptyList(),
    val isLoading: Boolean = false,
    val editingItem: InventoryItem? = null,
    val showAddDialog: Boolean = false,
    val userMessage: String? = null
) {
    /** Convenience property — avoids repeating the threshold magic number in the UI layer. */
    val lowStockItems: List<InventoryItem>
        get() = items.filter { it.isLowStock() }
}
