package com.example.inventoryapp.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

/**
 * Data Access Object for inventory item CRUD operations.
 *
 * Enhancement Milestone Four:
 * The JOIN-based query pattern introduced in Milestone Three is preserved
 * here as Room @Query annotations. Room validates the SQL at compile time,
 * meaning the correctness guarantee that was implicit in Milestone Three
 * (manually verified at runtime) is now enforced by the build system.
 *
 * The cursor-to-object mapping that required a private helper function in the
 * original DatabaseHelper is handled automatically by Room's code generation —
 * Room reads the column names from each @Query result and maps them to the
 * fields of [InventoryItemEntity] without any manual cursor parsing.
 *
 * All functions are [suspend] to run on the IO dispatcher via Room's built-in
 * coroutine support, configured in [AppDatabase].
 */
@Dao
interface InventoryItemDao {

    @Query("""
        SELECT i.*
        FROM   inventory_items i
        JOIN   users           u ON i.user_id = u.user_id
        WHERE  u.username = :username
        ORDER BY i.item_name ASC
    """)
    suspend fun getItemsForUser(username: String): List<InventoryItemEntity>

    @Query("""
        SELECT i.*
        FROM   inventory_items i
        JOIN   users           u ON i.user_id = u.user_id
        WHERE  u.username      = :username
          AND  i.quantity     <= :threshold
        ORDER BY i.quantity ASC
    """)
    suspend fun getLowStockItemsForUser(
        username: String,
        threshold: Int
    ): List<InventoryItemEntity>

    /**
     * Inserts a new inventory item. Returns the new row ID, or -1 on failure.
     */
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertItem(item: InventoryItemEntity): Long

    @Update
    suspend fun updateItem(item: InventoryItemEntity): Int

    @Query("DELETE FROM inventory_items WHERE item_id = :itemId")
    suspend fun deleteItem(itemId: Long): Int
}
