package com.example.inventoryapp.database

import android.util.Log
import com.example.inventoryapp.model.InventoryItem

/**
 * InventoryRepository mediates between the ViewModel's domain model
 * ([InventoryItem]) and the Room layer ([InventoryItemDao] / [InventoryItemEntity]).
 *
 * Enhancement Milestone Four:
 * In the original design, [DatabaseHelper] directly returned [InventoryItem]
 * objects constructed from raw cursor data. Room's DAOs return [InventoryItemEntity]
 * objects, which are database-layer representations. The mapping between the
 * two happens here, keeping the ViewModel and composables entirely unaware that
 * Room exists.
 *
 * @param inventoryItemDao DAO for inventory CRUD operations.
 * @param userRepository   Used to resolve username → user_id for inserts.
 */
class InventoryRepository(
    private val inventoryItemDao: InventoryItemDao,
    private val userRepository: UserRepository
) {
    companion object {
        private const val TAG = "InventoryRepository"
    }

    /**
     * Returns all inventory items for [username], mapped to domain objects.
     * The underlying JOIN query is defined in [InventoryItemDao.getItemsForUser].
     */
    suspend fun getInventoryItems(username: String): List<InventoryItem> {
        return try {
            inventoryItemDao.getItemsForUser(username).map { it.toDomain() }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching items: ${e.message}")
            emptyList()
        }
    }

    suspend fun getLowStockItems(
        username: String,
        threshold: Int = DatabaseHelper.LOW_STOCK_THRESHOLD
    ): List<InventoryItem> {
        return try {
            inventoryItemDao.getLowStockItemsForUser(username, threshold).map { it.toDomain() }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching low-stock items: ${e.message}")
            emptyList()
        }
    }

    suspend fun addInventoryItem(item: InventoryItem, username: String): Boolean {
        return try {
            val user = userRepository.getUser(username) ?: return false
            val entity = item.toEntity(userId = user.userId)
            inventoryItemDao.insertItem(entity) != -1L
        } catch (e: Exception) {
            Log.e(TAG, "Error adding item: ${e.message}")
            false
        }
    }

    /**
     * Updates an existing inventory item. The user_id is not changed on update.
     * @return True if exactly one row was updated.
     */
    suspend fun updateInventoryItem(item: InventoryItem): Boolean {
        return try {
            // user_id is required by the entity but is not changed on an update.
            // We pass 0L as a placeholder; Room's @Update matches on item_id only.
            val entity = item.toEntity(userId = 0L)
            inventoryItemDao.updateItem(entity) > 0
        } catch (e: Exception) {
            Log.e(TAG, "Error updating item: ${e.message}")
            false
        }
    }

    /**
     * Deletes the item with the given [itemId].
     * @return True if the row was deleted.
     */
    suspend fun deleteInventoryItem(itemId: Long): Boolean {
        return try {
            inventoryItemDao.deleteItem(itemId) > 0
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting item: ${e.message}")
            false
        }
    }

    // Mapping helpers 

    private fun InventoryItemEntity.toDomain(): InventoryItem = InventoryItem(
        id          = itemId,
        name        = itemName,
        description = itemDescription,
        quantity    = quantity,
        price       = price,
        category    = category
    )

    private fun InventoryItem.toEntity(userId: Long): InventoryItemEntity = InventoryItemEntity(
        itemId          = id,
        itemName        = name,
        itemDescription = description,
        quantity        = quantity,
        price           = price,
        category        = category,
        userId          = userId
    )
}
