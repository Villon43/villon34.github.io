package com.example.inventoryapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.inventoryapp.database.DatabaseHelper
import com.example.inventoryapp.ui.theme.InventoryAppTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * MainActivity — login and registration screen.
 *
 * Enhancement  Milestone Four:
 * Authentication calls are now suspend functions (because BCrypt hashing runs
 * on the IO dispatcher and must not block the main thread). This activity
 * dispatches them via [lifecycleScope.launch] with [Dispatchers.IO], matching
 * the coroutine pattern already used in [InventoryViewModel].
 */
class MainActivity : ComponentActivity() {

    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        databaseHelper = DatabaseHelper(this)

        setContent {
            InventoryAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    LoginScreen(
                        onLogin    = { username, password -> handleLogin(username, password) },
                        onRegister = { username, password -> handleRegister(username, password) }
                    )
                }
            }
        }
    }

    private fun handleLogin(username: String, password: String) {
        if (username.isBlank() || password.isBlank()) {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
            return
        }
        // BCrypt verification is CPU-intensive — always run on IO dispatcher.
        lifecycleScope.launch {
            val valid = withContext(Dispatchers.IO) {
                databaseHelper.authenticateUser(username, password)
            }
            if (valid) {
                val intent = Intent(this@MainActivity, InventoryActivity::class.java).apply {
                    putExtra("USERNAME", username)
                }
                startActivity(intent)
            } else {
                Toast.makeText(this@MainActivity, "Invalid username or password", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun handleRegister(username: String, password: String) {
        if (username.isBlank() || password.isBlank()) {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            val success = withContext(Dispatchers.IO) {
                databaseHelper.createUser(username, password)
            }
            if (success) {
                Toast.makeText(this@MainActivity, "Account created — please log in", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this@MainActivity, "Username already exists", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

// ── LoginScreen composable ────────────────────────────────────────────────────

@Composable
fun LoginScreen(
    onLogin: (String, String) -> Unit,
    onRegister: (String, String) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Inventory Manager",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Text(
            text = "Sign in to manage your inventory",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 32.dp)
        )
        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            singleLine = true
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            singleLine = true
        )
        Button(
            onClick = { onLogin(username, password) },
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
        ) { Text("Log In") }

        OutlinedButton(
            onClick = { onRegister(username, password) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Create Account") }
    }
}
