package com.example.inventoryapp.model

import com.example.inventoryapp.database.DatabaseHelper

/**
 * Data class representing a single inventory item.
 *
 * Enhancement  Milestone Three:
 * The isLowStock() function previously used a bare integer literal (5) as the
 * default threshold, duplicating the same magic number that appeared in
 * DatabaseHelper.getLowStockItems(). The default now references
 * DatabaseHelper.LOW_STOCK_THRESHOLD, establishing a single source of truth.
 * If the threshold is ever changed, both the database query and the UI badge
 * logic update automatically from one constant.
 */
data class InventoryItem(
    val id          : Long   = 0L,
    val name        : String,
    val description : String = "",
    val quantity    : Int,
    val price       : Double,
    val category    : String = ""
) {
    /**
     * Returns true if this item's quantity is at or below the low-stock threshold.
     *
     * @param threshold Minimum quantity before an item is considered low stock.
     *                  Defaults to [DatabaseHelper.LOW_STOCK_THRESHOLD] so the
     *                  UI badge and the database query always agree on the cutoff.
     */
    fun isLowStock(threshold: Int = DatabaseHelper.LOW_STOCK_THRESHOLD): Boolean {
        return quantity <= threshold
    }

    /**
     * Calculates the total inventory value of this item (quantity × price).
     */
    fun getTotalValue(): Double = quantity * price

    /**
     * Returns a compact single-line display string for this item.
     */
    fun getDisplayString(): String =
        "$name - Qty: $quantity - \$${String.format("%.2f", price)}"

    /**
     * Validates that required fields contain sensible values before persistence.
     */
    fun isValid(): Boolean = name.isNotBlank() && quantity >= 0 && price >= 0.0
}
