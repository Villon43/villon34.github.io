package com.example.inventoryapp

import android.Manifest
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.inventoryapp.ui.theme.InventoryAppTheme

/**
 * InventoryActivity — entry point for the inventory screen.
 *
 * Enhancement (Software Design & Engineering):
 * The original InventoryActivity contained ~350 lines spanning UI composables,
 * database calls, coroutine launches, permission handling, and SMS logic.
 * After the MVVM refactor this class has a single responsibility: bootstrapping
 * the Android component, delegating to the ViewModel, and wiring in the
 * platform-level SMS permission launcher (which requires an Activity reference
 * and cannot live in the ViewModel).
 *
 */
class InventoryActivity : ComponentActivity() {

    // viewModels() delegate creates the ViewModel scoped to this Activity's lifecycle.
    // It survives configuration changes (e.g. screen rotation) automatically.
    private val viewModel: InventoryViewModel by viewModels()

    private val requestSmsPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.onSmsPermissionResult(granted)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Extract username passed from the login screen; finish early if missing.
        val username = intent.getStringExtra("USERNAME") ?: ""
        if (username.isEmpty()) {
            finish()
            return
        }

        // Initialize the ViewModel with the username (triggers first data load).
        viewModel.initialize(username)

        // Check / request SMS permission.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            == PackageManager.PERMISSION_GRANTED
        ) {
            viewModel.onSmsPermissionResult(true)
        } else {
            requestSmsPermission.launch(Manifest.permission.SEND_SMS)
        }

        setContent {
            InventoryAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // Collect state as Compose State, lifecycle-aware.
                    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                    // Show one-shot Toast messages originating from the ViewModel.
                    uiState.userMessage?.let { message ->
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                        viewModel.onUserMessageShown()
                    }

                    // Render the stateless screen composable, passing ViewModel
                    // callbacks as lambdas. No logic lives in these lambdas —
                    // they simply delegate to the appropriate ViewModel function.
                    InventoryScreen(
                        uiState       = uiState,
                        onAddClicked  = viewModel::onAddItemClicked,
                        onSaveNew     = viewModel::addItem,
                        onSaveEdit    = viewModel::updateItem,
                        onDelete      = viewModel::deleteItem,
                        onEditClicked = viewModel::onEditItemClicked,
                        onDismiss     = viewModel::onDialogDismissed
                    )
                }
            }
        }
    }
}
