package com.example.inventoryapp.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Room entity representing a row in the [users] table.
 *
 * Enhancement Milestone Four:
 * The original schema was defined as a raw SQL string constant inside
 * DatabaseHelper. Room replaces that with an annotated data class that the
 * compiler validates at build time. The UNIQUE constraint on [username] is
 * preserved via the [indices] parameter on @Entity, and the column names
 * match the original schema so that the onDestructiveMigration() fallback
 * produces an identical table structure for fresh installs.
 *
 * Security: the [passwordHash] field stores a BCrypt hash, never a plaintext
 * password. See [UserRepository] for hashing and verification logic.
 */
@Entity(
    tableName = "users",
    indices = [Index(value = ["username"], unique = true)]
)
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "user_id")
    val userId: Long = 0L,

    @ColumnInfo(name = "username")
    val username: String,

    /**
     * BCrypt hash of the user's password.
     * The column is intentionally named "password" to match the original
     * schema; the field name makes clear that only hashes are stored here.
     */
    @ColumnInfo(name = "password")
    val passwordHash: String
)
