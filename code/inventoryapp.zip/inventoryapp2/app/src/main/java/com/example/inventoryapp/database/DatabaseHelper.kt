package com.example.inventoryapp.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.example.inventoryapp.model.InventoryItem

/**
 * DatabaseHelper manages SQLite database operations for the inventory app
 * Handles both user authentication and inventory item management
 */
class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "inventory_database.db"
        private const val DATABASE_VERSION = 1

        // Users table constants
        private const val TABLE_USERS = "users"
        private const val COLUMN_USER_ID = "user_id"
        private const val COLUMN_USERNAME = "username"
        private const val COLUMN_PASSWORD = "password"

        // Inventory items table constants
        private const val TABLE_INVENTORY = "inventory_items"
        private const val COLUMN_ITEM_ID = "item_id"
        private const val COLUMN_ITEM_NAME = "item_name"
        private const val COLUMN_ITEM_DESCRIPTION = "item_description"
        private const val COLUMN_ITEM_QUANTITY = "quantity"
        private const val COLUMN_ITEM_PRICE = "price"
        private const val COLUMN_ITEM_CATEGORY = "category"
        private const val COLUMN_ITEM_USER_ID = "user_id"

        // SQL statements for table creation
        private const val CREATE_USERS_TABLE = """
            CREATE TABLE $TABLE_USERS (
                $COLUMN_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_USERNAME TEXT UNIQUE NOT NULL,
                $COLUMN_PASSWORD TEXT NOT NULL
            )
        """

        private const val CREATE_INVENTORY_TABLE = """
            CREATE TABLE $TABLE_INVENTORY (
                $COLUMN_ITEM_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_ITEM_NAME TEXT NOT NULL,
                $COLUMN_ITEM_DESCRIPTION TEXT,
                $COLUMN_ITEM_QUANTITY INTEGER NOT NULL DEFAULT 0,
                $COLUMN_ITEM_PRICE REAL NOT NULL DEFAULT 0.0,
                $COLUMN_ITEM_CATEGORY TEXT,
                $COLUMN_ITEM_USER_ID INTEGER NOT NULL,
                FOREIGN KEY($COLUMN_ITEM_USER_ID) REFERENCES $TABLE_USERS($COLUMN_USER_ID)
            )
        """
    }

    override fun onCreate(db: SQLiteDatabase?) {
        // Create both users and inventory tables
        db?.execSQL(CREATE_USERS_TABLE)
        db?.execSQL(CREATE_INVENTORY_TABLE)
        Log.d("DatabaseHelper", "Database tables created successfully")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // Handle database upgrades by dropping and recreating tables
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_INVENTORY")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        onCreate(db)
        Log.d("DatabaseHelper", "Database upgraded from version $oldVersion to $newVersion")
    }

    /**
     * Creates a new user account in the database
     * @param username The desired username
     * @param password The user's password
     * @return True if account creation was successful, false if username already exists
     */
    fun createUser(username: String, password: String): Boolean {
        val db = this.writableDatabase
        return try {
            val values = ContentValues().apply {
                put(COLUMN_USERNAME, username)
                put(COLUMN_PASSWORD, password)
            }

            val result = db.insert(TABLE_USERS, null, values)
            result != -1L
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error creating user: ${e.message}")
            false
        } finally {
            db.close()
        }
    }

    /**
     * Authenticates a user's login credentials
     * @param username The username to authenticate
     * @param password The password to verify
     * @return True if credentials are valid, false otherwise
     */
    fun authenticateUser(username: String, password: String): Boolean {
        val db = this.readableDatabase
        return try {
            val cursor = db.query(
                TABLE_USERS,
                arrayOf(COLUMN_USER_ID),
                "$COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ?",
                arrayOf(username, password),
                null, null, null
            )

            val isValid = cursor.count > 0
            cursor.close()
            isValid
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error authenticating user: ${e.message}")
            false
        } finally {
            db.close()
        }
    }

    /**
     * Gets the user ID for a given username
     * @param username The username to look up
     * @return The user ID, or -1 if user not found
     */
    fun getUserId(username: String): Long {
        val db = this.readableDatabase
        return try {
            val cursor = db.query(
                TABLE_USERS,
                arrayOf(COLUMN_USER_ID),
                "$COLUMN_USERNAME = ?",
                arrayOf(username),
                null, null, null
            )

            if (cursor.moveToFirst()) {
                val userId = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_USER_ID))
                cursor.close()
                userId
            } else {
                cursor.close()
                -1L
            }
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error getting user ID: ${e.message}")
            -1L
        } finally {
            db.close()
        }
    }

    /**
     * Adds a new inventory item to the database
     * @param item The inventory item to add
     * @param username The username of the item owner
     * @return True if item was added successfully, false otherwise
     */
    fun addInventoryItem(item: InventoryItem, username: String): Boolean {
        val userId = getUserId(username)
        if (userId == -1L) return false

        val db = this.writableDatabase
        return try {
            val values = ContentValues().apply {
                put(COLUMN_ITEM_NAME, item.name)
                put(COLUMN_ITEM_DESCRIPTION, item.description)
                put(COLUMN_ITEM_QUANTITY, item.quantity)
                put(COLUMN_ITEM_PRICE, item.price)
                put(COLUMN_ITEM_CATEGORY, item.category)
                put(COLUMN_ITEM_USER_ID, userId)
            }

            val result = db.insert(TABLE_INVENTORY, null, values)
            result != -1L
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error adding inventory item: ${e.message}")
            false
        } finally {
            db.close()
        }
    }

    /**
     * Retrieves all inventory items for a specific user
     * @param username The username whose items to retrieve
     * @return List of inventory items belonging to the user
     */
    fun getInventoryItems(username: String): List<InventoryItem> {
        val userId = getUserId(username)
        if (userId == -1L) return emptyList()

        val items = mutableListOf<InventoryItem>()
        val db = this.readableDatabase

        try {
            val cursor = db.query(
                TABLE_INVENTORY,
                null,
                "$COLUMN_ITEM_USER_ID = ?",
                arrayOf(userId.toString()),
                null, null, null
            )

            while (cursor.moveToNext()) {
                val item = InventoryItem(
                    id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID)),
                    name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME)),
                    description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_DESCRIPTION)) ?: "",
                    quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_QUANTITY)),
                    price = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_ITEM_PRICE)),
                    category = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_CATEGORY)) ?: ""
                )
                items.add(item)
            }
            cursor.close()
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error retrieving inventory items: ${e.message}")
        } finally {
            db.close()
        }

        return items
    }

    /**
     * Updates an existing inventory item
     * @param item The updated inventory item
     * @return True if update was successful, false otherwise
     */
    fun updateInventoryItem(item: InventoryItem): Boolean {
        val db = this.writableDatabase
        return try {
            val values = ContentValues().apply {
                put(COLUMN_ITEM_NAME, item.name)
                put(COLUMN_ITEM_DESCRIPTION, item.description)
                put(COLUMN_ITEM_QUANTITY, item.quantity)
                put(COLUMN_ITEM_PRICE, item.price)
                put(COLUMN_ITEM_CATEGORY, item.category)
            }

            val rowsAffected = db.update(
                TABLE_INVENTORY,
                values,
                "$COLUMN_ITEM_ID = ?",
                arrayOf(item.id.toString())
            )
            rowsAffected > 0
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error updating inventory item: ${e.message}")
            false
        } finally {
            db.close()
        }
    }

    /**
     * Deletes an inventory item from the database
     * @param itemId The ID of the item to delete
     * @return True if deletion was successful, false otherwise
     */
    fun deleteInventoryItem(itemId: Long): Boolean {
        val db = this.writableDatabase
        return try {
            val rowsDeleted = db.delete(
                TABLE_INVENTORY,
                "$COLUMN_ITEM_ID = ?",
                arrayOf(itemId.toString())
            )
            rowsDeleted > 0
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error deleting inventory item: ${e.message}")
            false
        } finally {
            db.close()
        }
    }

    /**
     * Gets inventory items with low stock (quantity <= threshold)
     * @param username The username whose items to check
     * @param threshold The minimum quantity threshold (default: 5)
     * @return List of items with low stock
     */
    fun getLowStockItems(username: String, threshold: Int = 5): List<InventoryItem> {
        val userId = getUserId(username)
        if (userId == -1L) return emptyList()

        val items = mutableListOf<InventoryItem>()
        val db = this.readableDatabase

        try {
            val cursor = db.query(
                TABLE_INVENTORY,
                null,
                "$COLUMN_ITEM_USER_ID = ? AND $COLUMN_ITEM_QUANTITY <= ?",
                arrayOf(userId.toString(), threshold.toString()),
                null, null, null
            )

            while (cursor.moveToNext()) {
                val item = InventoryItem(
                    id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID)),
                    name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME)),
                    description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_DESCRIPTION)) ?: "",
                    quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_QUANTITY)),
                    price = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_ITEM_PRICE)),
                    category = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_CATEGORY)) ?: ""
                )
                items.add(item)
            }
            cursor.close()
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error retrieving low stock items: ${e.message}")
        } finally {
            db.close()
        }

        return items
    }
}