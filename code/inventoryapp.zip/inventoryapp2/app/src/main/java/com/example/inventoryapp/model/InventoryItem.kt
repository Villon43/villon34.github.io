package com.example.inventoryapp.model

/**
 * Data class representing an inventory item
 * Contains all the necessary information for tracking inventory items
 */
data class InventoryItem(
    val id: Long = 0L,
    val name: String,
    val description: String = "",
    val quantity: Int,
    val price: Double,
    val category: String = ""
) {
    /**
     * Checks if this item has low stock
     * @param threshold The minimum quantity threshold (default: 5)
     * @return True if quantity is at or below threshold
     */
    fun isLowStock(threshold: Int = 5): Boolean {
        return quantity <= threshold
    }

    /**
     * Calculates the total value of this inventory item
     * @return The total value (quantity * price)
     */
    fun getTotalValue(): Double {
        return quantity * price
    }

    /**
     * Creates a formatted string for displaying the item
     * @return A formatted string representation
     */
    fun getDisplayString(): String {
        return "$name - Qty: $quantity - $${String.format("%.2f", price)}"
    }

    /**
     * Validates that the inventory item has valid data
     * @return True if all required fields are valid
     */
    fun isValid(): Boolean {
        return name.isNotBlank() &&
                quantity >= 0 &&
                price >= 0.0
    }
}