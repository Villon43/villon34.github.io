package com.example.inventoryapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.inventoryapp.database.DatabaseHelper
import com.example.inventoryapp.model.InventoryItem
import com.example.inventoryapp.ui.theme.InventoryAppTheme
import kotlinx.coroutines.launch

/**
 * InventoryActivity manages the main inventory display and operations
 * Handles CRUD operations and SMS notifications for low stock items
 */
class InventoryActivity : ComponentActivity() {

    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var username: String
    private var hasSmsPermission by mutableStateOf(false)

    // Permission launcher for SMS functionality
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        hasSmsPermission = isGranted
        if (isGranted) {
            showToast("SMS notifications enabled")
        } else {
            showToast("SMS notifications disabled - app will continue without this feature")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Get username from login activity
        username = intent.getStringExtra("USERNAME") ?: ""
        if (username.isEmpty()) {
            finish()
            return
        }

        // Initialize database helper
        databaseHelper = DatabaseHelper(this)

        // Check SMS permission status
        checkSmsPermission()

        setContent {
            InventoryAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    InventoryScreen()
                }
            }
        }
    }

    /**
     * Checks and requests SMS permission if needed
     */
    private fun checkSmsPermission() {
        when (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)) {
            PackageManager.PERMISSION_GRANTED -> {
                hasSmsPermission = true
            }
            else -> {
                // Request SMS permission
                requestPermissionLauncher.launch(Manifest.permission.SEND_SMS)
            }
        }
    }

    /**
     * Main inventory screen composable
     */
    @Composable
    fun InventoryScreen() {
        var inventoryItems by remember { mutableStateOf<List<InventoryItem>>(emptyList()) }
        var showAddDialog by remember { mutableStateOf(false) }
        var editingItem by remember { mutableStateOf<InventoryItem?>(null) }

        // Load inventory items when screen first appears
        LaunchedEffect(Unit) {
            loadInventoryItems { items ->
                inventoryItems = items
                checkLowStockAndNotify(items)
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header with username and add button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Welcome, $username",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Inventory Items: ${inventoryItems.size}",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    modifier = Modifier.size(56.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Item")
                }
            }

            // Inventory items grid
            if (inventoryItems.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No inventory items yet.\nTap the + button to add your first item!",
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(inventoryItems) { item ->
                        InventoryItemCard(
                            item = item,
                            onEdit = { editingItem = it },
                            onDelete = {
                                deleteItem(it) {
                                    loadInventoryItems { items -> inventoryItems = items }
                                }
                            }
                        )
                    }
                }
            }
        }

        // Add item dialog
        if (showAddDialog) {
            AddEditItemDialog(
                item = null,
                onDismiss = { showAddDialog = false },
                onSave = { item ->
                    addItem(item) {
                        showAddDialog = false
                        loadInventoryItems { items -> inventoryItems = items }
                    }
                }
            )
        }

        // Edit item dialog
        editingItem?.let { item ->
            AddEditItemDialog(
                item = item,
                onDismiss = { editingItem = null },
                onSave = { updatedItem ->
                    updateItem(updatedItem) {
                        editingItem = null
                        loadInventoryItems { items -> inventoryItems = items }
                    }
                }
            )
        }
    }

    /**
     * Composable for displaying an individual inventory item
     */
    @Composable
    fun InventoryItemCard(
        item: InventoryItem,
        onEdit: (InventoryItem) -> Unit,
        onDelete: (Long) -> Unit
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onEdit(item) },
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.name,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (item.description.isNotBlank()) {
                            Text(
                                text = item.description,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                        if (item.category.isNotBlank()) {
                            Text(
                                text = "Category: ${item.category}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }

                    Row {
                        IconButton(onClick = { onEdit(item) }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit")
                        }
                        IconButton(onClick = { onDelete(item.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Quantity with low stock indicator
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Qty: ${item.quantity}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium
                        )
                        if (item.isLowStock()) {
                            Box(
                                modifier = Modifier
                                    .padding(start = 8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(MaterialTheme.colorScheme.error)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "LOW STOCK",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onError,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Text(
                        text = "${String.format("%.2f", item.price)}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }

    /**
     * Dialog for adding or editing inventory items
     */
    @Composable
    fun AddEditItemDialog(
        item: InventoryItem?,
        onDismiss: () -> Unit,
        onSave: (InventoryItem) -> Unit
    ) {
        var name by remember { mutableStateOf(item?.name ?: "") }
        var description by remember { mutableStateOf(item?.description ?: "") }
        var quantity by remember { mutableStateOf(item?.quantity?.toString() ?: "") }
        var price by remember { mutableStateOf(item?.price?.toString() ?: "") }
        var category by remember { mutableStateOf(item?.category ?: "") }

        Dialog(onDismissRequest = onDismiss) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = if (item == null) "Add New Item" else "Edit Item",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Item Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Description (Optional)") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )

                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Category (Optional)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = quantity,
                            onValueChange = { if (it.all { char -> char.isDigit() }) quantity = it },
                            label = { Text("Quantity") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = price,
                            onValueChange = {
                                if (it.matches(Regex("^\\d*\\.?\\d{0,2}$"))) price = it
                            },
                            label = { Text("Price") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancel")
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                val quantityInt = quantity.toIntOrNull() ?: 0
                                val priceDouble = price.toDoubleOrNull() ?: 0.0

                                if (name.isNotBlank() && quantityInt >= 0 && priceDouble >= 0) {
                                    val newItem = InventoryItem(
                                        id = item?.id ?: 0L,
                                        name = name.trim(),
                                        description = description.trim(),
                                        quantity = quantityInt,
                                        price = priceDouble,
                                        category = category.trim()
                                    )
                                    onSave(newItem)
                                }
                            },
                            enabled = name.isNotBlank() &&
                                    quantity.isNotBlank() &&
                                    price.isNotBlank()
                        ) {
                            Text(if (item == null) "Add" else "Save")
                        }
                    }
                }
            }
        }
    }

    /**
     * Loads inventory items from database
     */
    private fun loadInventoryItems(callback: (List<InventoryItem>) -> Unit) {
        lifecycleScope.launch {
            try {
                val items = databaseHelper.getInventoryItems(username)
                callback(items)
            } catch (e: Exception) {
                showToast("Error loading inventory items: ${e.message}")
                callback(emptyList())
            }
        }
    }

    /**
     * Adds a new inventory item to database
     */
    private fun addItem(item: InventoryItem, callback: () -> Unit) {
        lifecycleScope.launch {
            try {
                val success = databaseHelper.addInventoryItem(item, username)
                if (success) {
                    showToast("Item added successfully")
                    callback()
                } else {
                    showToast("Failed to add item")
                }
            } catch (e: Exception) {
                showToast("Error adding item: ${e.message}")
            }
        }
    }

    /**
     * Updates an existing inventory item in database
     */
    private fun updateItem(item: InventoryItem, callback: () -> Unit) {
        lifecycleScope.launch {
            try {
                val success = databaseHelper.updateInventoryItem(item)
                if (success) {
                    showToast("Item updated successfully")
                    callback()
                } else {
                    showToast("Failed to update item")
                }
            } catch (e: Exception) {
                showToast("Error updating item: ${e.message}")
            }
        }
    }

    /**
     * Deletes an inventory item from database
     */
    private fun deleteItem(itemId: Long, callback: () -> Unit) {
        lifecycleScope.launch {
            try {
                val success = databaseHelper.deleteInventoryItem(itemId)
                if (success) {
                    showToast("Item deleted successfully")
                    callback()
                } else {
                    showToast("Failed to delete item")
                }
            } catch (e: Exception) {
                showToast("Error deleting item: ${e.message}")
            }
        }
    }

    /**
     * Checks for low stock items and sends SMS notifications if permission granted
     */
    private fun checkLowStockAndNotify(items: List<InventoryItem>) {
        if (!hasSmsPermission) return

        lifecycleScope.launch {
            try {
                val lowStockItems = databaseHelper.getLowStockItems(username)
                if (lowStockItems.isNotEmpty()) {
                    val message = buildString {
                        append("Low Stock Alert:\n")
                        lowStockItems.take(3).forEach { item ->
                            append("${item.name}: ${item.quantity} left\n")
                        }
                        if (lowStockItems.size > 3) {
                            append("...and ${lowStockItems.size - 3} more items")
                        }
                    }

                    sendSmsNotification(message)
                }
            } catch (e: Exception) {
                // Silently handle SMS errors to not disrupt app functionality
                android.util.Log.e("InventoryActivity", "SMS notification error: ${e.message}")
            }
        }
    }

    /**
     * Sends SMS notification for low stock items
     */
    private fun sendSmsNotification(message: String) {
        try {
            // In a real app, you would get the phone number from user preferences
            // For this demo, we'll just show a toast that SMS would be sent
            showToast("SMS Alert: Low stock items detected!")

            // Uncomment below to actually send SMS (requires valid phone number)
            /*
            val smsManager = SmsManager.getDefault()
            val phoneNumber = "YOUR_PHONE_NUMBER" // Get from user preferences
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            */
        } catch (e: Exception) {
            android.util.Log.e("InventoryActivity", "Failed to send SMS: ${e.message}")
        }
    }

    /**
     * Shows a toast message to the user
     */
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}